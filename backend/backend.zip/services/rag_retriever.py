# backend/services/rag_retriever.py
import os
from typing import List, Dict, Any, Union
from uuid import uuid4

from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct, VectorParams, Distance
from PyPDF2 import PdfReader
from sentence_transformers import SentenceTransformer


# === Config ===
QDRANT_URL = os.getenv("QDRANT_URL", "http://localhost:6333")
QDRANT_COLLECTION = os.getenv("QDRANT_COLLECTION", "code2paper_chunks")

# Embedding model
EMBED_MODEL = os.getenv("EMBED_MODEL", "all-MiniLM-L6-v2")

# Initialize clients
qdrant = QdrantClient(QDRANT_URL)
embedder = SentenceTransformer(EMBED_MODEL)


# === Helpers ===
def extract_text_from_pdf(pdf_path: str) -> str:
    """Extract plain text from PDF file."""
    text = []
    try:
        reader = PdfReader(pdf_path)
        for page in reader.pages:
            text.append(page.extract_text() or "")
    except Exception as e:
        print(f"[PDF Error] {pdf_path}: {e}")
    return "\n".join(text)


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    """Split text into overlapping chunks for embedding."""
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size - overlap):
        chunk = " ".join(words[i:i + chunk_size])
        if chunk.strip():
            chunks.append(chunk)
    return chunks


def ensure_collection():
    """Create collection if not exists."""
    if not qdrant.collection_exists(QDRANT_COLLECTION):
        qdrant.create_collection(
            collection_name=QDRANT_COLLECTION,
            vectors_config=VectorParams(
                size=embedder.get_sentence_embedding_dimension(),
                distance=Distance.COSINE,
            ),
        )


# === Indexing ===
def index_paper(paper: Dict[str, Any]) -> None:
    """
    Extract text from PDF, chunk, embed, and push into Qdrant.
    paper: {
      "title": ..., "authors": ..., "year": ..., "doi": ..., "pdf_path": ...
    }
    """
    pdf_path = paper.get("pdf_path")
    if not pdf_path or not os.path.exists(pdf_path):
        print(f"[Indexing Skipped] No PDF found for {paper.get('title')}")
        return

    ensure_collection()

    text = extract_text_from_pdf(pdf_path)
    chunks = chunk_text(text)
    if not chunks:
        print(f"[Indexing Skipped] Empty text for {paper.get('title')}")
        return

    vectors = embedder.encode(chunks).tolist()

    points = []
    for idx, (chunk, vector) in enumerate(zip(chunks, vectors)):
        points.append(
            PointStruct(
                id=str(uuid4()),
                vector=vector,
                payload={
                    "title": paper.get("title"),
                    "doi": paper.get("doi"),
                    "year": paper.get("year"),
                    "authors": paper.get("authors"),
                    "chunk": chunk,
                    "chunk_id": idx,
                },
            )
        )

    qdrant.upsert(collection_name=QDRANT_COLLECTION, points=points)
    print(f"✅ Indexed {len(chunks)} chunks from {paper.get('title')}")


# === Retrieval ===
def query_chunks(
    queries: Union[str, List[str]], top_k: int = 5
) -> List[Dict[str, Any]]:
    """
    Search Qdrant for most relevant chunks given one or multiple queries.
    Returns list of dicts with text + metadata.
    """
    ensure_collection()

    if isinstance(queries, str):
        queries = [queries]

    results_all: List[Dict[str, Any]] = []

    for query in queries:
        query_vector = embedder.encode([query])[0].tolist()
        results = qdrant.search(
            collection_name=QDRANT_COLLECTION,
            query_vector=query_vector,
            limit=top_k,
        )

        for hit in results:
            results_all.append(
                {
                    "title": hit.payload.get("title"),
                    "doi": hit.payload.get("doi"),
                    "year": hit.payload.get("year"),
                    "authors": hit.payload.get("authors"),
                    "text": hit.payload.get("chunk"),
                    "score": hit.score,
                    "query": query,
                }
            )

    # Sort by score (best first), remove near-duplicates
    results_all.sort(key=lambda r: r["score"], reverse=True)
    seen = set()
    unique_results = []
    for r in results_all:
        key = (r["doi"], r["text"][:100])  # crude dedup
        if key not in seen:
            unique_results.append(r)
            seen.add(key)

    return unique_results[:top_k]
