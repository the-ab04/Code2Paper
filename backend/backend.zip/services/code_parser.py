# backend/services/code_parser.py

import nbformat
from nbformat.reader import NotJSONError
import re
from typing import Dict, List


def parse_notebook(nb_path: str) -> Dict[str, List[str]]:
    """
    Extract markdown, code blocks, and training logs from a Jupyter notebook (.ipynb).

    Args:
        nb_path (str): Path to the .ipynb file.

    Returns:
        dict: {
            "markdown": [list of markdown text],
            "code": [list of code blocks],
            "logs": [list of detected training logs or metrics],
            "datasets": [detected datasets],
            "metrics": [detected metrics]
        }
    """
    try:
        nb = nbformat.read(nb_path, as_version=4)
    except NotJSONError as e:
        raise ValueError(f"Invalid notebook format: {e}")
    except Exception as e:
        raise ValueError(f"Error reading notebook: {e}")

    md_blocks: List[str] = []
    code_blocks: List[str] = []
    logs: List[str] = []

    for cell in nb.cells:
        cell_type = cell.get("cell_type")
        source = cell.get("source", "").strip()

        if not source:
            continue  # Skip empty cells

        if cell_type == "markdown":
            md_blocks.append(source)

        elif cell_type == "code":
            code_blocks.append(source)

            # Detect metrics or logs (accuracy, loss, f1, precision, recall)
            for line in source.splitlines():
                if re.search(r"(accuracy|loss|f1|precision|recall)\s*[:=]\s*\d+(\.\d+)?", line, re.I):
                    logs.append(line.strip())

    # Simple dataset & metric detection across the notebook
    combined_text = "\n".join(md_blocks + code_blocks + logs)
    datasets = [ds for ds in ["MNIST", "CIFAR", "IMDB", "ImageNet", "COCO"] if re.search(ds, combined_text, re.I)]
    metrics = [m for m in ["accuracy", "precision", "recall", "f1", "auc", "loss"] if re.search(m, combined_text, re.I)]

    return {
        "markdown": md_blocks,
        "code": code_blocks,
        "logs": logs,
        "datasets": datasets,
        "metrics": metrics,
    }


if __name__ == "__main__":
    # ✅ Example usage for local testing
    test_path = "sample_inputs/sample_notebook.ipynb"
    try:
        facts = parse_notebook(test_path)
        print("Notebook facts extracted:")
        for key, value in facts.items():
            print(f"{key}: {value[:2]} ...")  # print first 2 entries per key
    except Exception as e:
        print(f"Error: {e}")
