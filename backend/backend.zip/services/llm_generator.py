# backend/services/llm_generator.py
from typing import Dict, Any, List
from config import GROQ_API_KEY, MODEL_NAME
from langchain_groq import ChatGroq
from services.rag_retriever import query_chunks  # ✅ new import
import json, re

SYSTEM_PROMPT = (
    "You are an assistant that writes structured academic paper sections.\n"
    "Rules:\n"
    "- Write concise, factual, formal academic text.\n"
    "- Ground your output in BOTH notebook facts and retrieved literature.\n"
    "- Use clear academic tone.\n"
    "- Insert citation placeholders in the format [CITATION: query] "
    "where query is the DOI or title from the provided chunks.\n"
    "- The References section must be a JSON array of strings "
    "(each string being a placeholder).\n"
    "- Return strictly valid JSON (no markdown, no code fences)."
)


def _get_llm(model_name: str | None = None):
    """Initialize the Groq LLM client."""
    if not GROQ_API_KEY:
        raise RuntimeError("GROQ_API_KEY is missing in config.")
    return ChatGroq(
        model=model_name or MODEL_NAME,
        temperature=0.2,
        groq_api_key=GROQ_API_KEY,
    )


def _extract_json(text: str) -> str:
    """Clean LLM output to ensure valid JSON."""
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.S)
    if fence:
        text = fence.group(1)

    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end != -1:
        text = text[start:end + 1]

    text = re.sub(r",\s*([}\]])", r"\1", text)
    text = (
        text.replace("\u201c", '"')
        .replace("\u201d", '"')
        .replace("\u2018", "'")
        .replace("\u2019", "'")
    )
    return text.strip()


def generate_sections(
    facts: Dict[str, Any],
    model_name: str | None = None,
    use_rag: bool = True,
    top_k: int = 5
) -> Dict[str, str]:
    """
    Generate academic paper sections using notebook facts + retrieved papers.
    """
    llm = _get_llm(model_name)

    # === Notebook context ===
    md = "\n\n".join(facts.get("markdown", []))[:4000]
    code_hint = "\n".join(facts.get("code", [])[:3])
    logs = "\n".join(facts.get("logs", [])[:10])
    datasets = ", ".join(facts.get("datasets", []))
    metrics = ", ".join(facts.get("metrics", []))

    # === Retrieved chunks from vector DB ===
    rag_context = ""
    if use_rag:
        queries = [
            facts.get("task", "machine learning"),
            *facts.get("datasets", []),
            *facts.get("methods", []),
        ]
        chunks = query_chunks(queries, top_k=top_k)
        if chunks:
            rag_context = "=== Retrieved Literature Chunks ===\n"
            for idx, ch in enumerate(chunks, 1):
                src = ch.get("doi") or ch.get("title") or f"Source {idx}"
                rag_context += f"[{idx}] {ch.get('text', '')} (Source: {src})\n"

    # === Prompt ===
    prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"=== Notebook Facts ===\n"
        f"Markdown (sample):\n{md}\n\n"
        f"Code (sample):\n{code_hint}\n\n"
        f"Training Logs (sample):\n{logs}\n\n"
        f"Datasets Mentioned: {datasets}\n\n"
        f"Metrics Mentioned: {metrics}\n\n"
        f"{rag_context}\n\n"
        "Return JSON with keys: "
        "title, abstract, introduction, methods, experiments, results, "
        "discussion, conclusion, references (as array of strings)."
    )

    # === LLM call ===
    resp = llm.invoke(prompt)
    raw = getattr(resp, "content", str(resp))
    cleaned = _extract_json(raw)

    try:
        data = json.loads(cleaned)
    except Exception:
        cleaned = re.sub(r",\s*([}\]])", r"\1", cleaned)
        data = json.loads(cleaned)

    # === Normalize output ===
    result: Dict[str, str] = {}
    for key in [
        "title", "abstract", "introduction", "methods",
        "experiments", "results", "discussion", "conclusion"
    ]:
        result[key] = str(data.get(key, "")).strip()

    refs = data.get("references", [])
    if isinstance(refs, list):
        result["references"] = "\n".join([str(r).strip() for r in refs if r])
    else:
        result["references"] = str(refs or "").strip()

    return result
