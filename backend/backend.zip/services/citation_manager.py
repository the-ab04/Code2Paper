# backend/services/citation_manager.py
import re
import requests
from typing import Dict, List

CROSSREF_API = "https://api.crossref.org/works"

def fetch_crossref_metadata(query: str) -> dict:
    """
    Fetch metadata from CrossRef using a title or DOI query.
    Returns the first matching metadata item or an empty dict if not found.
    """
    try:
        response = requests.get(
            CROSSREF_API,
            params={"query": query, "rows": 1, "mailto": "your-email@example.com"},  # 👈 include mailto for reliability
            timeout=8,
        )
        if response.status_code == 200:
            data = response.json()
            items = data.get("message", {}).get("items", [])
            if items:
                return items[0]
    except Exception as e:
        print(f"[CrossRef Error] Failed for '{query}': {e}")
    return {}

def format_reference(meta: dict) -> str:
    """
    Convert CrossRef metadata into IEEE-style reference.
    Example:
      J. Smith and K. Lee, "Deep Learning for NLP," IEEE Trans. Neural Networks, vol. 32, no. 5, pp. 120-130, 2021. DOI: 10.xxxx/xxxxx
    """
    title = meta.get("title", ["Unknown Title"])[0]
    authors_list = meta.get("author", [])
    authors = ", ".join(
        [f"{a.get('given','')[0]}. {a.get('family','')}" for a in authors_list if a.get("family")]
    ) if authors_list else "Unknown Author"
    year = meta.get("issued", {}).get("date-parts", [[None]])[0][0] or "n.d."
    container = meta.get("container-title", [""])[0]
    volume = meta.get("volume", "")
    issue = meta.get("issue", "")
    pages = meta.get("page", "")
    doi = meta.get("DOI", "N/A")

    ref = f"{authors}, \"{title},\" {container}"
    if volume:
        ref += f", vol. {volume}"
    if issue:
        ref += f", no. {issue}"
    if pages:
        ref += f", pp. {pages}"
    ref += f", {year}. DOI: {doi}"
    return ref

def enrich_references(sections: Dict[str, str]) -> Dict[str, str]:
    """
    1. Find [CITATION: ...] placeholders in all sections.
    2. Assign numbers [1], [2], ... consistently.
    3. Replace placeholders in text with [n].
    4. Generate IEEE-style reference list using CrossRef.
    """
    citation_pattern = re.compile(r"\[CITATION:\s*([^\]]+)\]")

    unique_queries: List[str] = []
    query_to_index: Dict[str, int] = {}

    # Step 1: Collect unique citation queries
    for sec_text in sections.values():
        for match in citation_pattern.findall(sec_text):
            query = match.strip()
            if query not in query_to_index:
                unique_queries.append(query)
                query_to_index[query] = len(unique_queries)  # numbering starts at 1

    # Step 2: Replace placeholders with [n]
    for sec_name, sec_text in sections.items():
        sections[sec_name] = citation_pattern.sub(
            lambda m: f"[{query_to_index.get(m.group(1).strip(), '?')}]",
            sec_text,
        )

    # Step 3: Build References section
    enriched_refs: List[str] = []
    for query in unique_queries:
        meta = fetch_crossref_metadata(query)
        if meta:
            ref_text = format_reference(meta)
        else:
            ref_text = query  # fallback to raw query
        enriched_refs.append(f"[{query_to_index[query]}] {ref_text}")

    sections["references"] = "\n".join(enriched_refs) if enriched_refs else "No references available."
    return sections
