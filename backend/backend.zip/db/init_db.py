# backend/db/init_db.py
from .base import Base, engine
from . import models  # make sure all models are imported so tables are registered

def init_db():
    """
    Initialize the PostgreSQL database.
    - Creates all tables if they don’t exist.
    - Should be called on FastAPI startup.
    """
    print("🔧 Initializing database...")
    Base.metadata.create_all(bind=engine)
    print("✅ Database tables ready.")
