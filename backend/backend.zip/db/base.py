# backend/db/base.py

import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

# ✅ Load .env variables if present
load_dotenv()

# ✅ Database URL (PostgreSQL + psycopg2 driver)
import os

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"postgresql+psycopg2://{os.getenv('POSTGRES_USER', 'postgres')}:"
    f"{os.getenv('POSTGRES_PASSWORD', 'qwerty')}@"
    f"{os.getenv('POSTGRES_HOST', 'localhost')}:"
    f"{os.getenv('POSTGRES_PORT', 5432)}/"
    f"{os.getenv('POSTGRES_DB', 'code2paper_db')}"
)


# ✅ Create Engine
# echo=True will log all SQL — good for debugging, set False in production
engine = create_engine(DATABASE_URL, echo=True, future=True)

# ✅ Session Local
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    future=True,
)

# ✅ Base class for ORM models
Base = declarative_base()

# ✅ Dependency for FastAPI routes
def get_db():
    """
    FastAPI dependency that provides a SQLAlchemy session.
    Automatically closes the session after request is done.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
