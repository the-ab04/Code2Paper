# backend/db/models.py

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    ForeignKey,
    DateTime,
    func,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship
from .base import Base


class User(Base):
    """User accounts (optional, only if you enable authentication)."""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(200), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)

    runs = relationship("Run", back_populates="user")


class Run(Base):
    """Each generation attempt (upload → output paper)."""
    __tablename__ = "runs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    status = Column(String(50), default="pending")

    input_file = Column(String(500))   # uploaded notebook/code path
    output_file = Column(String(500))  # generated DOCX/PDF path

    user = relationship("User", back_populates="runs")
    papers = relationship("Paper", back_populates="run")
    citations = relationship("Citation", back_populates="run")


class Paper(Base):
    """Metadata of external papers discovered and linked to a run."""
    __tablename__ = "papers"

    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(Integer, ForeignKey("runs.id"), nullable=False)

    title = Column(Text, nullable=False)
    authors = Column(Text, nullable=True)
    year = Column(Integer, nullable=True)
    venue = Column(String(255), nullable=True)
    doi = Column(String(255), nullable=True)
    url = Column(String(500), nullable=True)
    pdf_path = Column(String(500), nullable=True)  # stored OA PDF path

    __table_args__ = (UniqueConstraint("doi", name="uq_papers_doi"),)

    run = relationship("Run", back_populates="papers")
    citations = relationship("Citation", back_populates="paper")
    chunks = relationship("Chunk", back_populates="paper")


class Citation(Base):
    """Inline citation resolved during generation (links section text → paper)."""
    __tablename__ = "citations"

    id = Column(Integer, primary_key=True, index=True)
    run_id = Column(Integer, ForeignKey("runs.id"), nullable=False)
    paper_id = Column(Integer, ForeignKey("papers.id"), nullable=False)

    context = Column(Text, nullable=True)  # snippet of text where cited
    index = Column(Integer, nullable=False)  # [1], [2], ...

    run = relationship("Run", back_populates="citations")
    paper = relationship("Paper", back_populates="citations")


class Chunk(Base):
    """Optional: keep raw text of chunks aligned with Qdrant embeddings."""
    __tablename__ = "chunks"

    id = Column(Integer, primary_key=True, index=True)
    paper_id = Column(Integer, ForeignKey("papers.id"), nullable=False)

    chunk_id = Column(Integer, nullable=False)  # matches Qdrant payload "chunk_id"
    text = Column(Text, nullable=False)

    paper = relationship("Paper", back_populates="chunks")
